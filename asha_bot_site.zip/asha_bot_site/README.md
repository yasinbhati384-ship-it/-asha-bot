# Asha Bot — Browser Signal Dashboard

A mobile-friendly static website that runs in a browser and can be published with GitHub Pages.

## Important limitations
- This is a manual, rule-based educational dashboard.
- It is **not connected to Olymptrade** and does not read live prices/candles.
- It does not place trades. Do not enter trading credentials or API keys.
- Its displayed “visual strength” is a score, not an estimated probability of winning.

## Run locally
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new public repository, e.g. `asha-bot`.
2. Upload `index.html` to the repository root (the first page must be named exactly `index.html`). You can also upload `README.md`.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for GitHub to publish the site. The Pages screen will show the website URL.

## Use
1. Open your trading chart separately.
2. Select the same asset and timeframe on this site.
3. Tap the five candle buttons so they match the last five **closed** candles on the chart, oldest first.
4. Tap **GET SIGNAL**. Treat UP/DOWN/WAIT as a simple pattern label, not a reliable forecast.
